How To Install OpenDJ
Download the OpenDJ from http://forgerock.com/downloads-opendj.html
You can use the 2.4.0 stable release from but this version does not support the password reset from Control Panel so if you need that function please use any newer release or the Nightly Build.
You can install OpenDJ in two modes:

Graphical User Interface (GUI) mode. The GUI mode uses QuickSetup, a Java-based graphical tool that enables you to install and configure an OpenDJ directory server, load it with data and get it running in very little time.
Interactive Command-line mode. The interactive command-line utility prompts you for required information before the installation and configuration begin.
To Install OpenDJ in GUI mode
You can run QuickSetup remotely via Java Web Start, or locally from within the build that you have downloaded and unzipped.
If you run QuickSetup remotely, it automatically downloads and unzips the latest weekly build, and handles server configuration. Launch QuickSetup via Java Web Start.
Install locally
Once you have downloaded the OpenDJ Zip file, unpack it in the destination folder, and change to that folder:

$ unzip OpenDJ-2.4.0.zip
$ cd OpenDJ-2.4.0
To run QuickSetup locally:

From the top level of your installation directory, type the following command:
(Unix, Linux) $ setup
(Windows) > setup.bat

On Mac systems, double-click on the QuickSetup.app application to launch QuickSetup directly from the Finder.
Answer the questions in the installation wizard.
To Install OpenDJ in Command-Line Mode
From the top level of your installation directory, type the following command:
(Unix, Linux) $ setup --cli
(Windows) > setup.bat --cli

Follow the prompts to provide the required installation information.
Just for test purpose you can select Import Automatically-Generated Sample Data when you enter the Directory Data.

	If you want to enable the debug then change the Server Runtime Settings to:
-server -agentlib:jdwp=transport=dt_socket,address=localhost:8000,server=y,suspend=n,timeout=5000
You have installed the OpenDJ now you can install the plugin.

Properly install and configure the plugin in any OpenDJ instance
Before you install it stop the OpenDJ instance:

$ bin/stop-ds
Unzip the plugin archive to the install directory:

$ unzip ../OpenIDM-PassswordSync-extension.zip
Update the configuration by appending it to the config.ldif:

$ cat config/openidm-pwsync-plugin-config.ldif >> config/config.ldif
(you may want to change the default configuration first, but you can do it afterwards with dsconfig)

Copy files from different location.

Copy the schema :

$ cp <EXTRACTED DIR>/config/schema/90-openidm-pwsync-plugin.ldif config/schema/
Update the configuration by appending it to the config.ldif:

$ cat <EXTRACTED DIR>/config/openidm-pwsync-plugin-config.ldif >> config/config.ldif
(you may want to change the default configuration first, but you can do it afterwards with dsconfig)

Copy the plugin in the lib/extensions directory

$ cp <EXTRACTED DIR>/lib/extensions/openidm-account-status-notification-handler.jar lib/extensions/
Copy the required libraries to lib

$ cp <EXTRACTED DIR>/lib/webservices-api-2.0.1.jar lib/
$ cp <EXTRACTED DIR>/lib/webservices-rt-2.0.1.jar lib/
The certificate of OpenIDM PasswordSync service need to be installed into the truststore and the client certificate and private key needs to be installed into the keystore.

The archive comes with some sample keys but you can generate and use your own.
The sample server key is identical with the one that the Netbeans installs when it uses any WSIT (http://wsit.java.net/) functionality.  You can verify that by running this command.

Verify the keystore of GlassFish:

$ keytool -list -keystore <GF_HOME>/domains/domain1/config/keystore.jks -storepass changeit
Keystore type: JKS
Keystore provider: SUN
Your keystore contains 4 entries
xws-security-server, 2010.11.13., PrivateKeyEntry,&nbsp;
Certificate fingerprint (MD5): E4:E3:A9:02:3C:B0:36:0C:C1:48:6E:0E:3E:5C:5E:84
wssip, 2010.11.13., PrivateKeyEntry,&nbsp;
Certificate fingerprint (MD5): 1A:0E:E9:69:7D\:D0:80:AD:5C:85:47:91:EB:0D:11:B1
xws-security-client, 2010.11.13., PrivateKeyEntry,&nbsp;
Certificate fingerprint (MD5): D1:45:A1:A9:6D:A9:57:9F:69:35:E3:4C:63:B6:98:C9
s1as, 2010.01.17., PrivateKeyEntry,&nbsp;
Certificate fingerprint (MD5): 09:85:83:6F:BA:9F:7B:47\:D5:3D:60:1B:6C:49\:D6:AB
Many good documentation are available if you are willing to generate your own keys.

http://www.jroller.com/gmazza/entry/using_openssl_to_create_certificates

How to generate and configure new self-signed certificate 
Create a private key for the certificate:

$ keytool -genkey -alias xws-security-client -keyalg rsa \
-dname "CN=9d1e4520-0cdc-11e0-81e0-0800200c9a66,OU=OpenIDM,O=ForgeRock,L=Oslo,S=N/A,C=NO" \
-keystore config/keystore -storetype JKS
In this case, the value of the -dname argument should be changed so that it is suitable for your environment.

The value of the CN attribute must be the OID of your ResourceType in your OpenIDM configuration, the value of the O attribute should be the name of the company or organization, and C should be the two-character country abbreviation. You will be interactively prompted for both a password to protect the contents of the keystore and a password to protect the private key. Both passwords should be the same.

Generate a self-signed certificate for the key with the command:

$ keytool -selfcert -alias xws-security-client -validity 3653 \
-keystore config/keystore -storetype JKS
When you are prompted for the keystore password, enter the same password that you provided previously.

Create a text file with the keystore password config/keystore.pin:

$ echo [enter the keystore password here] > config/keystore.pin
The file should only contain the password that you chose to protect the contents of the keystore.

Export the public key for the certificate that you just created:

$ keytool -export -alias xws-security-client \
-file config/OpenIDM-LDAP-client-cert.txt -rfc -keystore config/keystore \
-storetype JKS
Import that exported public key and the certificate into the truststore of GlassFish:

$ keytool -import -alias xws-security-client \
-file config/OpenIDM-LDAP-client-cert.txt -keystore <GF_HOME>/domains/domain1/config/cacerts.jks \
-storetype JKS
Export the public key for the certificate of PasswordSync Service from GlassFish:

$ keytool -export -alias xws-security-server \
-file config/OpenIDM-server-cert.txt -rfc -keystore <GF_HOME>/domains/domain1/config/keystore.jks \
-storetype JKS
Create a new trust store and import the server certificate into it:

$ keytool -import -alias xws-security-server \
-file config/OpenIDM-server-cert.txt -keystore config/truststore \
-storetype JKS
Type yes when you are prompted about whether you want to trust the certificate.

Unless you want to generate other keys you can use the sample ones.

If you didn't configured the LDAPS then the config directory does not contain any keystore and truststore. You can copy the files otherwise you can copy the certificates and keys to the existing stores. 
Copy the keystore files to the config directory:

$ cp <EXTRACTED DIR>/config/sample-keystore config/keystore
$ cp <EXTRACTED DIR>/config/sample-keystore.pin config/keystore.pin
$ cp <EXTRACTED DIR>/config/sample-truststore config/truststore
or rename the files if you extracted the archive to the install directory: 

$ mv config/sample-keystore config/keystore
$ mv config/sample-keystore.pin config/keystore.pin
$ mv config/sample-truststore config/truststore
If you configured the LDAPS before you would need to import the certificates and the private key.

$ keytool -import -alias xws-security-server \
-file OpenIDM-server-cert.txt -keystore config/truststore \
-storetype JKS
$ keytool -importkeystore -srckeystore config/sample-keystore -destkeystore config/keystore \
-srcstoretype JKS -deststoretype JKS -srcstorepass changeit -srckeypass changeit \
-deststorepass <copy the value from the config/keystore.pin> -srcalias xws-security-client \
-destkeypass <copy the value from the config/keystore.pin> -destalias xws-security-client \
-noprompt
Make sure all certificates and private key are in place:

$ keytool -list -keystore config/truststore -storepass changeit
Keystore type: JKS
Keystore provider: SUN
Your keystore contains 1 entry
xws-security-server, 2011.01.17., trustedCertEntry,
Certificate fingerprint (MD5): E4:E3:A9:02:3C:B0:36:0C:C1:48:6E:0E:3E:5C:5E:84
$ keytool -list -keystore config/keystore -storepass changeit
Keystore type: JKS
Keystore provider: SUN
Your keystore contains 1 entry
xws-security-client, 2011.01.17., PrivateKeyEntry,&nbsp;
Certificate fingerprint (MD5): AA:89:D8:D8:4E:2C:4F:F9:DE:73:2B:5C:89:DD:03:75
If you don't use LDAPS then you need to enable the two keymanagers in config/config.ldif  

dn: cn=JKS,cn=Key Manager Providers,cn=config
objectClass: ds-cfg-key-manager-provider
objectClass: ds-cfg-file-based-key-manager-provider
objectClass: top
ds-cfg-enabled: true
ds-cfg-java-class: org.opends.server.extensions.FileBasedKeyManagerProvider
ds-cfg-key-store-file: config/keystore
ds-cfg-key-store-type: JKS
ds-cfg-key-store-pin-file: config/keystore.pin
cn: JKS

dn: cn=JKS,cn=Trust Manager Providers,cn=config
objectClass: ds-cfg-file-based-trust-manager-provider
objectClass: ds-cfg-trust-manager-provider
objectClass: top
ds-cfg-enabled: true
ds-cfg-java-class: org.opends.server.extensions.FileBasedTrustManagerProvider
ds-cfg-trust-store-type: JKS
ds-cfg-trust-store-file: config/truststore
cn: JKS

To get more details you can enable the debug logger 

dn: cn=File-Based Debug Logger,cn=Loggers,cn=config
objectClass: ds-cfg-log-publisher
objectClass: ds-cfg-debug-log-publisher
objectClass: ds-cfg-file-based-debug-log-publisher
objectClass: top
ds-cfg-asynchronous: false
cn: File-Based Debug Logger
ds-cfg-enabled: true
ds-cfg-java-class: org.opends.server.loggers.debug.TextDebugLogPublisher
ds-cfg-default-debug-level: error
ds-cfg-log-file-permissions: 640
ds-cfg-log-file: logs/debug

Customize the configuration of the Notification Handler.

Notification Handler Config
dn: cn=OpenIDM Notification Handler,cn=Account Status Notification Handlers,cn=config
objectClass: top
objectClass: ds-cfg-account-status-notification-handler
objectClass: ds-cfg-openidm-account-status-notification-handler
cn: OpenIDM Notification Handler
ds-cfg-java-class: com.forgerock.openidm.pwsync.OpenidmAccountStatusNotificationHandler
ds-cfg-enabled: true
ds-cfg-attribute-type: entryUUID
ds-cfg-attribute-type: uid
ds-cfg-log-file: logs/pwsync
ds-cfg-update-interval: 10 seconds
ds-cfg-referrals-url: http://localhost:8080/OpenIDM/passwordSyncService?wsdl
ds-cfg-realm: xwssecurityserver
ds-cfg-ssl-cert-nickname: xws-security-client
ds-cfg-key-manager-provider: cn=JKS,cn=Key Manager Providers,cn=config
ds-cfg-trust-manager-provider: cn=JKS,cn=Trust Manager Providers,cn=config

You have configured the Password notification handler.

Before you start make sure the WSDL is available otherwise the server won't start. 

Start the OpenDJ instance:

$ bin/start-ds
You should notice a line like this: 

[] category=EXTENSIONS severity=INFORMATION msgID=1049147 msg=Loaded extension from file '.../OpenDJ-2.4.0/lib/extensions/openidm-account-status-notification-handler.jar' (build <unknown>, revision <unknown>)

Activating the plugin so that password changes are captured and processed by the plugin:

$ dsconfig set-password-policy-prop \
--policy-name "Default Password Policy" \
--set "account-status-notification-handler:OpenIDM Notification Handler" \
--hostname localhost \
--port 4444 \
--trustStorePath config/admin-truststore \
--bindDN cn=Directory\ Manager \
--bindPassword <your_password> \
--no-prompt
Testing 
Connect as cn=Directory Manager:

$ bin/ldapmodify -p 389 -D "cn=Directory Manager" -w <your_password>
dn: uid=user.0,ou=people,dc=example,dc=com
changetype: modify
replace: userPassword
userPassword: newPassword
-
Processing MODIFY request for uid=user.0,ou=people,dc=example,dc=com
MODIFY operation successful for DN uid=user.0,ou=people,dc=example,dc=com
Connect as user:

$ bin/ldapmodify -p 389 -D "uid=user.0,ou=people,dc=example,dc=com" -w password
dn: uid=user.0,ou=people,dc=example,dc=com
changetype: modify
replace: userPassword
userPassword: newPassword
-
Processing MODIFY request for uid=user.0,ou=people,dc=example,dc=com
MODIFY operation successful for DN uid=user.0,ou=people,dc=example,dc=com